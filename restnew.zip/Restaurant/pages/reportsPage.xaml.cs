﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;
using PdfSharp;
using PdfSharp.Pdf;
using PdfSharp.Drawing;

namespace Restaurant.pages
{
    /// <summary>
    /// Логика взаимодействия для reportsPage.xaml
    /// </summary>
    public partial class reportsPage : Page
    {
        public reportsPage()
        {
            InitializeComponent();
        }

        private void ExcelReportBtn_Click(object sender, RoutedEventArgs e)
        {
            {
                Excel.Application app = new Excel.Application();

                Excel.Workbook workbook = app.Workbooks.Add(Type.Missing);

                Excel.Worksheet worksheet = app.Worksheets[1];


                worksheet.Range["A1"].Value = "Название";
                worksheet.Range["B1"].Value = "Категория";
                worksheet.Range["C1"].Value = "Цена";
                worksheet.Range["D1"].Value = "Вес";
                worksheet.Range["E1"].Value = "Кол-во";

                List<Product1> products = entities.GetContext().Product1.ToList();

                worksheet.Range["A1", "E1"].Font.Bold = true;
                worksheet.Range["A1", "E1"].HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;

                int i = 2;
                foreach (Product1 product in products)
                {
                    worksheet.Range["A" + i].Value = product.Name;
                    worksheet.Range["B" + i].Value = product.Category1.Name;
                    worksheet.Range["C" + i].Value = product.Price;
                    worksheet.Range["D" + i].Value = product.Weight;
                    worksheet.Range["E" + i].Value = product.Count;

                    worksheet.Range["A1", "E1"].Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

                    worksheet.Range["A" + i, "E" + i].Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                    i++;
                }
                app.Columns.AutoFit();
                app.Visible = true;
            }
        }

        private void PdfReportBtn_Click(object sender, RoutedEventArgs e)
        {
            PdfDocument document = new PdfDocument();
            document.Info.Title = "Отчет";

            PdfPage page = document.AddPage();

            XGraphics gfx = XGraphics.FromPdfPage(page);

            XFont font = new XFont("Verdana", 11, XFontStyle.BoldItalic);

            gfx.DrawString("В этом месяце на склад были доставлены следующие товары", font, XBrushes.Black, new XPoint(250, 120), XStringFormats.Center);

            List<Product1> products = entities.GetContext().Product1.ToList();

            foreach(Product1 product in products)
            {

            }


            const string filename = "Отчет.pdf";

            document.Save(filename);

            Process.Start(filename);
        }
    }
}

