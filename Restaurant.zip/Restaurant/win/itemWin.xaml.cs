﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Restaurant.win
{
    /// <summary>
    /// Логика взаимодействия для itemWin.xaml
    /// </summary>
    public partial class itemWin : Window
    {
        private Product1 _product;
        private entities _context = entities.GetContext();
        List<string> category = new List<string>();
        public itemWin(Product1 product)
        {
            InitializeComponent();
            _product = product;
            _context.Category1.ToList().ForEach((el) => {
                category.Add(el.Name);
            });
            cbCategory.ItemsSource = category;
            txbName.Text = _product.Name;
            txbCost.Text = _product.Price.ToString();
            txbCount.Text = _product.Count.ToString();
            txbDesc.Text = _product.Description;
            txbWeight.Text = _product.Weight.ToString();
        }

        private void btnAddItem_Click(object sender, RoutedEventArgs e)
        {
            try
            { 
            var x = _context.Product1.Find(_product.id);
            x.Name = txbName.Text;
            x.Description = txbDesc.Text;
            x.Count = int.Parse(txbCount.Text);
            x.Price = double.Parse(txbCost.Text);
            x.Weight = double.Parse(txbWeight.Text);
            x.CategoryId = cbCategory.SelectedIndex;
            _context.SaveChanges();
            }
            catch
            {

            }
            this.Close();
        }
    }
}
