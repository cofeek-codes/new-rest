﻿using Restaurant.win;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Restaurant.pages
{
    /// <summary>
    /// Логика взаимодействия для stockList.xaml
    /// </summary>
    public partial class stockList : Page
    {
        private entities _context = entities.GetContext();
        List<string> category = new List<string>();
        public stockList()
        {
            InitializeComponent();
            _context.Category1.ToList().ForEach((el) =>
            {
                category.Add(el.Name);
            });
            UpdateSource();
        }

        private void UpdateSource()
        {
            dtgItems.ItemsSource = _context.Product1.ToList();

            cbCategory.ItemsSource = category;
        }

        private void btnAddItem_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var x = new Product1()
                {
                    Name = txbName.Text,
                    Description = txbDesc.Text,
                    Count = int.Parse(txbCount.Text),
                    Price = double.Parse(txbCost.Text),
                    Weight = double.Parse(txbWeight.Text),
                    CategoryId = cbCategory.SelectedIndex
                };

                entities.GetContext().Product1.Add(x);
                entities.GetContext().SaveChanges();

                txbName.Text = "";
                txbCost.Text = "";
                txbCount.Text = "";
                txbDesc.Text = "";
                txbWeight.Text = "";
                UpdateSource();
            }
            catch
            {

            }
        }
        private void dtgItems_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var x = new itemWin((Product1)dtgItems.SelectedItem);
            x.ShowDialog();
            UpdateSource();
        }

        private void dtgItems_KeyDown(object sender, MouseButtonEventArgs e)
        {
            try
            {
                _context.Product1.Remove((Product1)dtgItems.SelectedItem);
                _context.SaveChanges();
            }
            catch
            {

            }

            UpdateSource();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Global.frm.GoBack();
        }
    }
}
